[CmdletBinding()]
param(
    [ValidateSet('Apply', 'Status', 'Restore')]
    [string]$Mode = 'Apply',

    [string]$ExtensionPath,

    [string]$BackupDirectory
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$PatchVersion = '1'
$PatchMarker = "codex-workspace-history-patch:v$PatchVersion"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$HistoryRoot = Join-Path $PSScriptRoot 'history'

function Get-Sha256 {
    param([Parameter(Mandatory)][string]$Path)

    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-TextSha256 {
    param([Parameter(Mandatory)][string]$Text)

    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = $Utf8NoBom.GetBytes($Text)
        return ([BitConverter]::ToString($sha256.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant()
    }
    finally {
        $sha256.Dispose()
    }
}

function Read-Utf8Text {
    param([Parameter(Mandatory)][string]$Path)

    return [IO.File]::ReadAllText($Path, $Utf8NoBom)
}

function Write-Utf8Text {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Text
    )

    [IO.File]::WriteAllText($Path, $Text, $Utf8NoBom)
}

function Resolve-CodexExtensionPath {
    param([string]$RequestedPath)

    if ($RequestedPath) {
        $resolved = Resolve-Path -LiteralPath $RequestedPath -ErrorAction Stop
        return $resolved.Path.TrimEnd('\', '/')
    }

    $candidateRoots = @(
        (Join-Path $env:USERPROFILE '.vscode\extensions'),
        (Join-Path $env:USERPROFILE '.vscode-insiders\extensions'),
        (Join-Path $env:USERPROFILE '.cursor\extensions')
    )

    $candidates = foreach ($root in $candidateRoots) {
        if (-not (Test-Path -LiteralPath $root -PathType Container)) {
            continue
        }

        foreach ($directory in Get-ChildItem -LiteralPath $root -Directory -Filter 'openai.chatgpt-*' -ErrorAction SilentlyContinue) {
            $packagePath = Join-Path $directory.FullName 'package.json'
            if (-not (Test-Path -LiteralPath $packagePath -PathType Leaf)) {
                continue
            }

            try {
                $package = Read-Utf8Text $packagePath | ConvertFrom-Json
                if ($package.publisher -ne 'openai' -or $package.name -ne 'chatgpt') {
                    continue
                }

                [pscustomobject]@{
                    Path = $directory.FullName
                    Version = [string]$package.version
                    InstalledTimestamp = [long]($package.__metadata.installedTimestamp)
                }
            }
            catch {
                Write-Warning "Skipping unreadable extension manifest: $packagePath"
            }
        }
    }

    $selected = $candidates |
        Sort-Object -Property @{ Expression = 'InstalledTimestamp'; Descending = $true }, @{ Expression = 'Version'; Descending = $true } |
        Select-Object -First 1

    if ($null -eq $selected) {
        throw 'No installed openai.chatgpt VS Code extension was found. Pass -ExtensionPath explicitly.'
    }

    return $selected.Path.TrimEnd('\', '/')
}

function Get-AssetFiles {
    param([Parameter(Mandatory)][string]$ResolvedExtensionPath)

    $assetsPath = Join-Path $ResolvedExtensionPath 'webview\assets'
    if (-not (Test-Path -LiteralPath $assetsPath -PathType Container)) {
        throw "Webview assets directory does not exist: $assetsPath"
    }

    return @(
        Get-ChildItem -LiteralPath $assetsPath -File -Filter 'app-initial-*.js' | Sort-Object Length -Descending
        Get-ChildItem -LiteralPath $assetsPath -File -Filter '*.js' |
            Where-Object { $_.Name -notlike 'app-initial-*.js' } |
            Sort-Object Length -Descending
    )
}

function Find-Asset {
    param(
        [Parameter(Mandatory)][object[]]$Assets,
        [Parameter(Mandatory)][string[]]$Needles
    )

    foreach ($asset in $Assets) {
        $text = Read-Utf8Text $asset.FullName
        $hasEveryNeedle = $true
        foreach ($needle in $Needles) {
            if (-not $text.Contains($needle)) {
                $hasEveryNeedle = $false
                break
            }
        }

        if ($hasEveryNeedle) {
            return [pscustomobject]@{ Path = $asset.FullName; Text = $text }
        }
    }

    return $null
}

function Get-HistoryMethodBody {
    param([Parameter(Mandatory)][string]$Text)

    $start = $Text.IndexOf('async listRecentThreads')
    if ($start -lt 0) {
        return $null
    }

    $end = $Text.IndexOf('async hydrateThreads', $start)
    if ($end -lt 0) {
        $end = [Math]::Min($Text.Length, $start + 5000)
    }

    return $Text.Substring($start, $end - $start)
}

function Get-PatchState {
    param([Parameter(Mandatory)][string]$ResolvedExtensionPath)

    $packagePath = Join-Path $ResolvedExtensionPath 'package.json'
    $extensionScriptPath = Join-Path $ResolvedExtensionPath 'out\extension.js'
    if (-not (Test-Path -LiteralPath $packagePath -PathType Leaf)) {
        throw "Extension manifest does not exist: $packagePath"
    }
    if (-not (Test-Path -LiteralPath $extensionScriptPath -PathType Leaf)) {
        throw "Extension host script does not exist: $extensionScriptPath"
    }

    $packageText = Read-Utf8Text $packagePath
    $extensionScriptText = Read-Utf8Text $extensionScriptPath
    $package = $packageText | ConvertFrom-Json
    $assets = Get-AssetFiles $ResolvedExtensionPath
    $historyAsset = Find-Asset -Assets $assets -Needles @('async listRecentThreads', 'recent_threads')
    $refreshAsset = Find-Asset -Assets $assets -Needles @('active-workspace-roots-updated', 'refreshRecentConversations')

    if ($null -eq $historyAsset) {
        throw 'Could not locate the minified module that implements listRecentThreads.'
    }
    if ($null -eq $refreshAsset) {
        throw 'Could not locate the minified module that handles active-workspace-roots-updated.'
    }

    $historyMethodBody = Get-HistoryMethodBody $historyAsset.Text
    $hasPackagePatch = $packageText.Contains('"chatgpt.threadHistoryScope"')
    $hasExtensionHostPatch = $extensionScriptText.Contains('codexWorkspaceHistoryPatch:')
    $hasHistoryPatch = $historyAsset.Text.Contains('getCodexWorkspaceHistoryScope')
    $hasRefreshPatch = $refreshAsset.Text.Contains($PatchMarker)
    $isPatched = $hasPackagePatch -and $hasExtensionHostPatch -and $hasHistoryPatch -and $hasRefreshPatch
    $hasPartialPatch = ($hasPackagePatch -or $hasExtensionHostPatch -or $hasHistoryPatch -or $hasRefreshPatch) -and -not $isPatched
    $hasNativeCwdFilter = -not $hasHistoryPatch -and $null -ne $historyMethodBody -and [regex]::IsMatch($historyMethodBody, '(?:^|[,\{])cwd:')

    return [pscustomobject]@{
        ExtensionPath = $ResolvedExtensionPath
        Version = [string]$package.version
        PackagePath = $packagePath
        ExtensionScriptPath = $extensionScriptPath
        PackageText = $packageText
        ExtensionScriptText = $extensionScriptText
        HistoryAssetPath = $historyAsset.Path
        HistoryAssetText = $historyAsset.Text
        RefreshAssetPath = $refreshAsset.Path
        RefreshAssetText = $refreshAsset.Text
        IsPatched = $isPatched
        HasPartialPatch = $hasPartialPatch
        HasNativeCwdFilter = $hasNativeCwdFilter
    }
}

function Add-PackageSetting {
    param([Parameter(Mandatory)][string]$Text)

    if ($Text.Contains('"chatgpt.threadHistoryScope"')) {
        return $Text
    }

    $anchor = "`t`t`t`t`"chatgpt.followUpQueueMode`": {"
    $anchorIndex = $Text.IndexOf($anchor)
    if ($anchorIndex -lt 0) {
        throw 'The package.json configuration anchor was not found.'
    }

    $setting = @"
				"chatgpt.threadHistoryScope": {
					"description": "Choose whether Codex thread history shows only chats from the current workspace folders or chats from all workspaces.",
					"type": "string",
					"enum": [
						"currentWorkspace",
						"all"
					],
					"enumDescriptions": [
						"Show chats whose working directory exactly matches a current workspace folder.",
						"Show chats from every workspace."
					],
					"default": "currentWorkspace",
					"scope": "window"
				},
"@

    $patched = $Text.Insert($anchorIndex, $setting)
    $null = $patched | ConvertFrom-Json
    return $patched
}

function Patch-ExtensionHostScript {
    param([Parameter(Mandatory)][string]$Text)

    if ($Text.Contains('codexWorkspaceHistoryPatch:')) {
        return $Text
    }

    $handlerMatch = [regex]::Match(
        $Text,
        '(?<whole>["'']active-workspace-roots["'']:async\(\)=>\(\{roots:(?<roots>[A-Za-z_$][A-Za-z0-9_$]*\(\))\}\))'
    )
    if (-not $handlerMatch.Success) {
        throw 'The active-workspace-roots host handler anchor was not found.'
    }

    $searchStart = [Math]::Max(0, $handlerMatch.Index - 100000)
    $searchText = $Text.Substring($searchStart, $handlerMatch.Index - $searchStart)
    $workspaceChangeMatches = [regex]::Matches(
        $searchText,
        '(?<vscode>[A-Za-z_$][A-Za-z0-9_$]*)\.workspace\.onDidChangeWorkspaceFolders'
    )
    if ($workspaceChangeMatches.Count -eq 0) {
        throw 'Could not infer the VS Code API identifier used by the extension host bundle.'
    }
    $vscodeIdentifier = $workspaceChangeMatches[$workspaceChangeMatches.Count - 1].Groups['vscode'].Value
    $rootsExpression = $handlerMatch.Groups['roots'].Value
    $newHandler = '"active-workspace-roots":async()=>({roots:' + $rootsExpression + ',threadHistoryScope:' +
        $vscodeIdentifier + '.workspace.getConfiguration("chatgpt").get("threadHistoryScope","currentWorkspace"),' +
        'codexWorkspaceHistoryPatch:"v' + $PatchVersion + '"})'
    $patched = $Text.Remove($handlerMatch.Index, $handlerMatch.Length).Insert($handlerMatch.Index, $newHandler)

    $configurationPattern = [regex]::Escape($vscodeIdentifier) +
        '\.workspace\.onDidChangeConfiguration\((?<event>[A-Za-z_$][A-Za-z0-9_$]*)=>\{(?<font>\(\k<event>\.affectsConfiguration\("chat\.fontSize"\)\|\|\k<event>\.affectsConfiguration\("chat\.editor\.fontSize"\)\)&&this\.broadcastChatFontSettings\(\))\}\)'
    $configurationRegex = [regex]::new($configurationPattern)
    $configurationMatches = $configurationRegex.Matches($patched)
    if ($configurationMatches.Count -ne 1) {
        throw "Expected one Codex configuration listener anchor, found $($configurationMatches.Count)."
    }

    $patched = $configurationRegex.Replace($patched, {
        param($match)
        $eventIdentifier = $match.Groups['event'].Value
        $fontHandler = $match.Groups['font'].Value
        return $vscodeIdentifier + '.workspace.onDidChangeConfiguration(' + $eventIdentifier + '=>{' +
            $eventIdentifier + '.affectsConfiguration("chatgpt.threadHistoryScope")&&this.broadcastToAllViews({type:"active-workspace-roots-updated"});' +
            $fontHandler + '})'
    }, 1)

    return $patched
}

function Patch-HistoryAsset {
    param([Parameter(Mandatory)][string]$Text)

    if ($Text.Contains('getCodexWorkspaceHistoryScope')) {
        return $Text
    }

    $constructorAnchor = 'getHistoryLimit:this.runtimeSettings.getRecentConversationDiscoveryLimit,onHistoryLoaded:'
    $constructorMatches = [regex]::Matches($Text, [regex]::Escape($constructorAnchor))
    if ($constructorMatches.Count -ne 1) {
        throw "Expected one thread-store construction anchor, found $($constructorMatches.Count)."
    }
    $patched = $Text.Replace(
        $constructorAnchor,
        'getHistoryLimit:this.runtimeSettings.getRecentConversationDiscoveryLimit,getCodexWorkspaceHistoryScope:async()=>this.fetchFromHost("active-workspace-roots"),onHistoryLoaded:'
    )

    $methodPattern = 'async listRecentThreads\(\{cursor:(?<cursor>[A-Za-z_$][A-Za-z0-9_$]*),limit:(?<limit>[A-Za-z_$][A-Za-z0-9_$]*),background:(?<background>[A-Za-z_$][A-Za-z0-9_$]*)=!1\}\)\{let (?<request>[A-Za-z_$][A-Za-z0-9_$]*)=\{(?<properties>limit:\k<limit>,cursor:\k<cursor>,sortKey:this\.params\.requestClient\.getCompatibleThreadSortKey\(this\.recentConversationSortKey\),modelProviders:null,archived:!1,sourceKinds:[A-Za-z_$][A-Za-z0-9_$]*,useStateDbOnly:this\.params\.hostId!==[A-Za-z_$][A-Za-z0-9_$]*)\},(?<response>[A-Za-z_$][A-Za-z0-9_$]*)=await this\.params\.requestClient\.sendRequest\(`thread/list`,\k<request>,\k<background>\?\{priority:`background`,source:`recent_threads`\}:\{source:`recent_threads`\}\);return\{\.\.\.\k<response>,data:\k<response>\.data\.filter\((?<filter>[A-Za-z_$][A-Za-z0-9_$]*)\)\}\}'
    $methodRegex = [regex]::new($methodPattern)
    $methodMatches = $methodRegex.Matches($patched)
    if ($methodMatches.Count -ne 1) {
        throw "Expected one listRecentThreads implementation anchor, found $($methodMatches.Count)."
    }

    $patched = $methodRegex.Replace($patched, {
        param($match)
        $cursor = $match.Groups['cursor'].Value
        $limit = $match.Groups['limit'].Value
        $background = $match.Groups['background'].Value
        $request = $match.Groups['request'].Value
        $properties = $match.Groups['properties'].Value
        $response = $match.Groups['response'].Value
        $filter = $match.Groups['filter'].Value
        return 'async listRecentThreads({cursor:' + $cursor + ',limit:' + $limit + ',background:' + $background + '=!1}){' +
            'let __codexWorkspaceHistoryState=await this.params.getCodexWorkspaceHistoryScope(),' +
            '__codexWorkspaceHistoryRoots=Array.isArray(__codexWorkspaceHistoryState?.roots)?__codexWorkspaceHistoryState.roots:[],' +
            '__codexWorkspaceHistoryCwd=__codexWorkspaceHistoryState?.threadHistoryScope===`all`||__codexWorkspaceHistoryRoots.length===0?null:__codexWorkspaceHistoryRoots,' +
            $request + '={' + $properties + ',...__codexWorkspaceHistoryCwd==null?{}:{cwd:__codexWorkspaceHistoryCwd}},' +
            $response + '=await this.params.requestClient.sendRequest(`thread/list`,' + $request + ',' + $background + '?{priority:`background`,source:`recent_threads`}:{source:`recent_threads`});' +
            'return{...' + $response + ',data:' + $response + '.data.filter(' + $filter + ')}}'
    }, 1)

    return $patched
}

function Patch-RefreshAsset {
    param([Parameter(Mandatory)][string]$Text)

    if ($Text.Contains($PatchMarker)) {
        return $Text
    }

    $managerMatch = [regex]::Match(
        $Text,
        '(?<manager>[A-Za-z_$][A-Za-z0-9_$]*)\((?<scope>[A-Za-z_$][A-Za-z0-9_$]*),e\.hostId\)\.refreshRecentConversations'
    )
    if (-not $managerMatch.Success) {
        throw 'Could not infer the recent-conversation manager identifiers.'
    }
    $managerIdentifier = $managerMatch.Groups['manager'].Value
    $scopeIdentifier = $managerMatch.Groups['scope'].Value

    $caseRegex = [regex]::new('case`active-workspace-roots-updated`:(?<body>.*?);break (?<label>[A-Za-z_$][A-Za-z0-9_$]*);')
    $caseMatches = $caseRegex.Matches($Text)
    if ($caseMatches.Count -ne 1) {
        throw "Expected one active-workspace-roots-updated handler, found $($caseMatches.Count)."
    }

    return $caseRegex.Replace($Text, {
        param($match)
        return 'case`active-workspace-roots-updated`:' + $match.Groups['body'].Value + ';' +
            '/*' + $PatchMarker + '*/' + $managerIdentifier + '(' + $scopeIdentifier + ',`local`).refreshRecentConversations().catch(()=>{});' +
            'break ' + $match.Groups['label'].Value + ';'
    }, 1)
}

function New-Change {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$OriginalText,
        [Parameter(Mandatory)][string]$PatchedText
    )

    if ($OriginalText -ceq $PatchedText) {
        throw "No content change was produced for $Path"
    }

    return [pscustomobject]@{
        Path = $Path
        OriginalText = $OriginalText
        PatchedText = $PatchedText
        OriginalSha256 = Get-TextSha256 $OriginalText
        PatchedSha256 = Get-TextSha256 $PatchedText
    }
}

function Save-Backups {
    param(
        [Parameter(Mandatory)][string]$ResolvedExtensionPath,
        [Parameter(Mandatory)][string]$Version,
        [Parameter(Mandatory)][object[]]$Changes,
        [Parameter(Mandatory)][string]$Operation
    )

    $timestamp = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmss.fffZ')
    $safeVersion = $Version -replace '[^A-Za-z0-9._-]', '_'
    $runDirectory = Join-Path $HistoryRoot "$timestamp-$safeVersion-$($Operation.ToLowerInvariant())"
    $filesDirectory = Join-Path $runDirectory 'files'
    $null = New-Item -ItemType Directory -Path $filesDirectory -Force

    $entries = foreach ($change in $Changes) {
        $relativePath = $change.Path.Substring($ResolvedExtensionPath.Length).TrimStart('\', '/')
        $backupPath = Join-Path $filesDirectory $relativePath
        $backupParent = Split-Path -Parent $backupPath
        $null = New-Item -ItemType Directory -Path $backupParent -Force
        Copy-Item -LiteralPath $change.Path -Destination $backupPath -Force

        $backupHash = Get-Sha256 $backupPath
        if ($backupHash -ne $change.OriginalSha256) {
            throw "Backup verification failed for $($change.Path)"
        }

        [pscustomobject]@{
            RelativePath = $relativePath.Replace('\', '/')
            OriginalSha256 = $change.OriginalSha256
            PlannedSha256 = $change.PatchedSha256
        }
    }

    $manifest = [ordered]@{
        SchemaVersion = 1
        PatchVersion = $PatchVersion
        Operation = $Operation
        CreatedAtUtc = [DateTime]::UtcNow.ToString('o')
        ExtensionPath = $ResolvedExtensionPath
        ExtensionVersion = $Version
        Files = @($entries)
    }
    Write-Utf8Text -Path (Join-Path $runDirectory 'manifest.json') -Text ($manifest | ConvertTo-Json -Depth 8)
    return $runDirectory
}

function Write-ResultFile {
    param(
        [Parameter(Mandatory)][string]$RunDirectory,
        [Parameter(Mandatory)][string]$Status,
        [string]$Message
    )

    $result = [ordered]@{
        Status = $Status
        CompletedAtUtc = [DateTime]::UtcNow.ToString('o')
        Message = $Message
    }
    Write-Utf8Text -Path (Join-Path $RunDirectory 'result.json') -Text ($result | ConvertTo-Json -Depth 4)
}

function Apply-Changes {
    param(
        [Parameter(Mandatory)][string]$ResolvedExtensionPath,
        [Parameter(Mandatory)][string]$Version,
        [Parameter(Mandatory)][object[]]$Changes,
        [Parameter(Mandatory)][string]$Operation
    )

    $runDirectory = Save-Backups -ResolvedExtensionPath $ResolvedExtensionPath -Version $Version -Changes $Changes -Operation $Operation
    try {
        foreach ($change in $Changes) {
            Write-Utf8Text -Path $change.Path -Text $change.PatchedText
            $actualHash = Get-Sha256 $change.Path
            if ($actualHash -ne $change.PatchedSha256) {
                throw "Post-write verification failed for $($change.Path)"
            }
        }

        Write-ResultFile -RunDirectory $runDirectory -Status 'success' -Message "$Operation completed and all file hashes were verified."
        return $runDirectory
    }
    catch {
        foreach ($change in $Changes) {
            $relativePath = $change.Path.Substring($ResolvedExtensionPath.Length).TrimStart('\', '/')
            $backupPath = Join-Path (Join-Path $runDirectory 'files') $relativePath
            if (Test-Path -LiteralPath $backupPath -PathType Leaf) {
                Copy-Item -LiteralPath $backupPath -Destination $change.Path -Force
            }
        }
        Write-ResultFile -RunDirectory $runDirectory -Status 'rolled_back' -Message $_.Exception.Message
        throw
    }
}

function Show-PatchState {
    param([Parameter(Mandatory)]$State)

    [pscustomobject]@{
        ExtensionPath = $State.ExtensionPath
        ExtensionVersion = $State.Version
        State = if ($State.IsPatched) { 'patched' } elseif ($State.HasPartialPatch) { 'partial-patch' } elseif ($State.HasNativeCwdFilter) { 'native-support' } else { 'unpatched' }
        HistoryAsset = $State.HistoryAssetPath
        RefreshAsset = $State.RefreshAssetPath
        HistoryDirectory = $HistoryRoot
    } | Format-List | Out-String | Write-Host
}

function Invoke-Restore {
    param(
        [Parameter(Mandatory)][string]$ResolvedExtensionPath,
        [Parameter(Mandatory)][string]$Version,
        [string]$RequestedBackupDirectory
    )

    $sourceDirectory = $RequestedBackupDirectory
    if (-not $sourceDirectory) {
        $sourceDirectory = Get-ChildItem -LiteralPath $HistoryRoot -Directory -ErrorAction SilentlyContinue |
            Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'manifest.json') } |
            Sort-Object Name -Descending |
            ForEach-Object {
                $manifest = Read-Utf8Text (Join-Path $_.FullName 'manifest.json') | ConvertFrom-Json
                if ($manifest.Operation -eq 'Apply' -and $manifest.ExtensionPath -eq $ResolvedExtensionPath) {
                    $_.FullName
                }
            } |
            Select-Object -First 1
    }

    if (-not $sourceDirectory) {
        throw 'No matching Apply backup was found. Pass -BackupDirectory explicitly.'
    }
    $sourceDirectory = (Resolve-Path -LiteralPath $sourceDirectory -ErrorAction Stop).Path
    $sourceManifestPath = Join-Path $sourceDirectory 'manifest.json'
    $sourceManifest = Read-Utf8Text $sourceManifestPath | ConvertFrom-Json
    if ($sourceManifest.ExtensionPath -ne $ResolvedExtensionPath) {
        throw 'The selected backup belongs to a different extension directory.'
    }

    $changes = foreach ($file in $sourceManifest.Files) {
        $relativePath = ([string]$file.RelativePath).Replace('/', '\')
        $targetPath = Join-Path $ResolvedExtensionPath $relativePath
        $backupPath = Join-Path (Join-Path $sourceDirectory 'files') $relativePath
        if (-not (Test-Path -LiteralPath $targetPath -PathType Leaf)) {
            throw "Restore target is missing: $targetPath"
        }
        if (-not (Test-Path -LiteralPath $backupPath -PathType Leaf)) {
            throw "Restore source is missing: $backupPath"
        }

        $currentText = Read-Utf8Text $targetPath
        $restoredText = Read-Utf8Text $backupPath
        New-Change -Path $targetPath -OriginalText $currentText -PatchedText $restoredText
    }

    $runDirectory = Apply-Changes -ResolvedExtensionPath $ResolvedExtensionPath -Version $Version -Changes @($changes) -Operation 'Restore'
    Write-Host "Restore completed. Pre-restore files were backed up to: $runDirectory"
}

$resolvedExtensionPath = Resolve-CodexExtensionPath $ExtensionPath
$state = Get-PatchState $resolvedExtensionPath

if ($Mode -eq 'Status') {
    Show-PatchState $state
    exit 0
}

if ($Mode -eq 'Restore') {
    Invoke-Restore -ResolvedExtensionPath $state.ExtensionPath -Version $state.Version -RequestedBackupDirectory $BackupDirectory
    exit 0
}

Show-PatchState $state
if ($state.IsPatched) {
    Write-Host 'The selected extension is already fully patched. No files were changed.'
    exit 0
}
if ($state.HasNativeCwdFilter) {
    Write-Host 'The selected extension already has a native cwd filter for recent threads. No files were changed.'
    exit 0
}
if ($state.HasPartialPatch) {
    throw 'A partial patch was detected. Restore the latest backup or reinstall the extension before applying again.'
}

$patchedPackage = Add-PackageSetting $state.PackageText
$patchedExtensionScript = Patch-ExtensionHostScript $state.ExtensionScriptText
$patchedHistoryAsset = Patch-HistoryAsset $state.HistoryAssetText
$patchedRefreshAsset = Patch-RefreshAsset $state.RefreshAssetText

$changes = @(
    (New-Change -Path $state.PackagePath -OriginalText $state.PackageText -PatchedText $patchedPackage),
    (New-Change -Path $state.ExtensionScriptPath -OriginalText $state.ExtensionScriptText -PatchedText $patchedExtensionScript),
    (New-Change -Path $state.HistoryAssetPath -OriginalText $state.HistoryAssetText -PatchedText $patchedHistoryAsset),
    (New-Change -Path $state.RefreshAssetPath -OriginalText $state.RefreshAssetText -PatchedText $patchedRefreshAsset)
)

$backupRun = Apply-Changes -ResolvedExtensionPath $state.ExtensionPath -Version $state.Version -Changes $changes -Operation 'Apply'
$verifiedState = Get-PatchState $resolvedExtensionPath
if (-not $verifiedState.IsPatched) {
    throw 'Files were written, but the complete patch markers were not detected during final verification.'
}

Write-Host "Patch applied successfully. Backup and manifest: $backupRun"
Write-Host 'Reload the VS Code window once. The default scope is Current Workspace; choose All in the Codex: Thread History Scope setting when needed.'
