# Distribution notice

This archive contains only independently authored patching scripts and documentation.
It does not contain the OpenAI Codex VS Code extension, any original extension asset,
or any file copied from an installed extension.

The scripts operate only on a Codex VS Code extension that the user has already
installed. Review the scripts before running them. This project is unofficial and
is not affiliated with or endorsed by OpenAI.

OpenAI's applicable terms and the license shipped with the installed extension
remain controlling. This notice is not legal advice.
