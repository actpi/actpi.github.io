# Codex VS Code 工作区历史补丁

这个补丁为已安装的 Codex VS Code 扩展补上工作区会话过滤：

- 默认只显示 `cwd` 与当前 VS Code 工作区根目录精确匹配的会话。
- 多根工作区会一次传入全部根目录。
- 在 VS Code 设置里将 `Codex: Thread History Scope` 切换为 `All`，可以显示全部工作区的会话。
- 工作区目录或该设置变化时，历史列表会重新加载。
- 会话重命名、归档和恢复逻辑保持不变。

补丁只做本地文件复制、精确文本替换和 SHA-256 校验；不下载或执行第三方代码，也不读取会话内容。

## 使用

解压附件并进入 `codex-vscode-workspace-history-patch-v1` 目录，然后在 PowerShell 中运行：

```powershell
& '.\Apply-CodexWorkspaceHistoryPatch.ps1' -Mode Status
& '.\Apply-CodexWorkspaceHistoryPatch.ps1' -Mode Apply
```

应用后执行一次 `Developer: Reload Window`。扩展更新会安装到新目录并覆盖补丁；如果新版仍没有原生 `cwd` 过滤，再运行同一个 `-Mode Apply` 命令即可。脚本会自动选择最近安装的 `openai.chatgpt` 扩展，并执行以下保护：

1. 先检查新版是否已经原生为最近会话请求加入 `cwd`；有原生支持时不修改。
2. 在修改任何扩展文件前，把全部目标文件复制到 `history/<时间戳>-<版本>-apply/files/`。
3. 记录原始哈希、计划哈希、扩展版本和路径。
4. 修改后重新校验；任何一步失败都会从本次备份自动回滚。
5. 已完整应用时保持幂等，不重复修改。

如自动定位不符合实际安装位置，可显式指定：

```powershell
& '.\Apply-CodexWorkspaceHistoryPatch.ps1' `
  -Mode Apply `
  -ExtensionPath 'C:\Users\you\.vscode\extensions\openai.chatgpt-版本-平台'
```

## 恢复

恢复前，脚本仍会先备份当前文件，因此恢复操作也可追溯：

```powershell
& '.\Apply-CodexWorkspaceHistoryPatch.ps1' -Mode Restore
```

默认恢复当前扩展目录最近一次 `Apply` 的备份；也可通过 `-BackupDirectory` 指定某次历史目录。

## 注意

- 修改 Marketplace 扩展文件可能让 VS Code 显示“扩展已修改/损坏”的完整性提示；重新安装扩展即可回到官方版本。
- 补丁依赖扩展当前的构建结构。未来版本结构发生较大变化时，脚本会在备份/写入前停止，而不会猜测性修改。
- `thread/list` 的 `cwd` 是精确匹配；如果会话是在工作区根目录之外或不同路径表示（例如 Windows 与 WSL 路径不一致）创建的，请临时切换为 `All`。

相关依据：

- 功能请求：<https://github.com/openai/codex/issues/25319>
- `thread/list` 协议说明：<https://github.com/openai/codex/blob/main/codex-rs/app-server/README.md>
