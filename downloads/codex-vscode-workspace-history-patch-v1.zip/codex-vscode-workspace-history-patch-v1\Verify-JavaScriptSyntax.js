"use strict";

const fs = require("fs");
const path = require("path");

function findTypeScript() {
  const executableDirectory = path.dirname(process.execPath);
  for (const entry of fs.readdirSync(executableDirectory, { withFileTypes: true })) {
    if (!entry.isDirectory()) {
      continue;
    }

    const candidate = path.join(
      executableDirectory,
      entry.name,
      "resources",
      "app",
      "extensions",
      "node_modules",
      "typescript",
      "lib",
      "typescript.js",
    );
    if (fs.existsSync(candidate)) {
      return candidate;
    }
  }

  throw new Error("Could not find the TypeScript parser bundled with VS Code.");
}

const files = process.argv.slice(2);
if (files.length === 0) {
  throw new Error("Pass one or more JavaScript files to verify.");
}

const ts = require(findTypeScript());
let hasSyntaxErrors = false;

for (const file of files) {
  const source = fs.readFileSync(file, "utf8");
  const parsed = ts.createSourceFile(
    file,
    source,
    ts.ScriptTarget.Latest,
    false,
    ts.ScriptKind.JS,
  );

  if (parsed.parseDiagnostics.length === 0) {
    process.stdout.write(`SYNTAX_OK ${file}\n`);
    continue;
  }

  hasSyntaxErrors = true;
  for (const diagnostic of parsed.parseDiagnostics) {
    const position = parsed.getLineAndCharacterOfPosition(diagnostic.start ?? 0);
    const message = ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n");
    process.stderr.write(
      `${file}:${position.line + 1}:${position.character + 1}: ${message}\n`,
    );
  }
}

process.exitCode = hasSyntaxErrors ? 1 : 0;
